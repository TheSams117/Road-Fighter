package modelo;

import java.util.ArrayList;

/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 * Universidad Icesi (Cali - Colombia)    ~ 
 * Autores: Juan Sebastian Puerta Ordo�es ~ 
 * 			Jeiner Alexis Bonilla Chavez  ~ 
 * 			Sergio Andres Lozada Sanchez  ~      
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 */
public class RoadFigther {
	//Atributos
	private int cantidadJugadores;
	private int cantidadCarreras;
	
	//Relaciones.
	private TablaPuntajes tablaPuntajes;
	private Carretera carretera;
	private Carretera carreteraSeleccionada;
	private Jugador jugador;
	
	//Constructor
	public RoadFigther() {
		
		cantidadJugadores = 0;
		cantidadCarreras = 0;
		carretera=null;
		carreteraSeleccionada=null;
		jugador=null;
		tablaPuntajes = new TablaPuntajes();
		
	}
		
	public int darCantidadJugadores() {
		return cantidadJugadores;
	}

	public void cambiarCantidadJugadores(int pCantidadJugadores) {
		cantidadJugadores = pCantidadJugadores;
	}

	public int darCantidadCarreras() {
		return cantidadCarreras;
	}

	public void cambiarCantidadCarreras(int pCantidadCarreras) {
		cantidadCarreras = pCantidadCarreras;
	}

	public TablaPuntajes darTablaPuntajes() {
		return tablaPuntajes;
	}

	public Carretera darCarretera() {
		return carretera;
	}

	public void cambiarCarretera(Carretera pCarretera) {
		carretera = pCarretera;
	}
	
	public Carretera darCarreteraSeleccionada() {
		return carreteraSeleccionada;
	}

	public void cambiarCarreteraSeleccionada(Carretera pCarreteraSeleccionada) {
		carreteraSeleccionada = pCarreteraSeleccionada;
	}

	/**
	 * Nombre: darJugador
	 * Permite dar la raiz del arbol binario
	 * @return jugador - Raiz del arbol binario
	 */
	public Jugador darJugador() {
		return jugador;
	}

	/**Nombre: darJugadoresOrdenadosPorNombre
	 * Da un ArrayList de Jugador
	 * @return losJugadores - ArrayList de jugadores
	 */
	public ArrayList<Jugador> darJugadoresOrdenadosPorNombre() {
		
		ArrayList<Jugador> losJugadores= new ArrayList<Jugador>();
		jugador.inorden(losJugadores);
		ordenarJugadoresPorNombre(losJugadores);
		return losJugadores;
		
	}
	
	/**
	 * Nombre: ordenarJugadoresPorNombre
	 * Permite ordenar un ArrayList de Jugador por medio del nombre
	 * @param losJugadores - ArrayList que se desea ordenar
	 */
	public void ordenarJugadoresPorNombre(ArrayList<Jugador> losJugadores) {
		for(int i = 1; i < losJugadores.size(); i++) {
			for(int j = i; j > 0 && losJugadores.get(j-1).compareTo(losJugadores.get(j)) > 0; j--) {
				Jugador auxJugador = losJugadores.get(j);
				losJugadores.set(j, losJugadores.get(j-1));
				losJugadores.set(j-1, auxJugador);
			}
		}
	}
	
	/**
	 * Nombre: agregarJugadorPorNombre
	 * Permite agregar un Jugador por el puntaje
	 * @param elJugador - Jugador el cual se desea agregar
	 * @post Jugador agregado al arbol binario
	 */
	public void agregarJugadorPorNombre(Jugador elJugador) {
		
		if(jugador == null) {
			jugador = elJugador;
		}else {
			jugador.insertarPorNombre(elJugador);
		}
		cantidadJugadores++;
		
	}
	
	/**
	 * Nombre: eliminarJugadorPorNombre
	 * Este metodo permite eliminar un Jugador del arbol
	 * por medio del nombre
	 * @param elNombre - Nombre del Jugador el cual se desea eliminar
	 * @post Jugador del arbol binario eliminado
	 */
	public void eliminarJugadorPorNombre(String elNombre) {
		
		if(jugador.getNombre().compareTo(elNombre) == 0) {
			jugador = jugador.elimininarPorNombre(elNombre);
		}else {
			jugador.elimininarPorNombre(elNombre);
		}
		cantidadJugadores--;
		
	}

	/**
	 * Nombre: buscarNombre
	 * Este metodo se encarga de llamar al metodo de la clase Jugador
	 * buscarJugadorPorNombre y lanza excepcion cuando el nombre no ha sido
	 * encontrado
	 * @param elNombre - Nombre del jugador al cual se desea buscar
	 * @return Jugador con el nombre pasado como parametro
	 * @throws JugadorNoEncontradoException
	 */
	public Jugador buscarNombre(String elNombre) throws JugadorNoEncontradoException{
		
		if(jugador.buscarJugadorPorNombre(elNombre) == null) {
			throw new JugadorNoEncontradoException("El jugador no ha sido encontreado");
		}else {
			return jugador.buscarJugadorPorNombre(elNombre);
		}
		
	}
	
	/**
	 * Nombre: cambiarJugador
	 * Permite cambiar la raiz de un arbol binario
	 * @param pJugador - Nueva raiz del arbol binario
	 * @post Raiz del arbol cambiada
	 */
	public void cambiarJugador(Jugador pJugador) {
		jugador = pJugador;
	}
	
	public void agregarCarretera(String pAutomovil,String pCarretera) {
		Carretera nueva = nuevaPartida(pAutomovil,pCarretera);
		carreteraSeleccionada=nueva;
		Carretera carreteraActual = carretera;
		if(carreteraActual==null) {
			carretera=nueva;
		}else {
			while(carreteraActual.darCarreteraSiguiente() != null) {
				carreteraActual=carreteraActual.darCarreteraSiguiente();
			}
			carreteraActual.cambiarCarreteraSiguiente(nueva);
		}
		
	}
	
	

		
	public Automovil[] darAutomovil() {
		return null;
	}
	
	public Carretera buscarCarretera(int laCarretera) {
		return null;
	}
		
	public void ordenarCarreterasLista() {
			
	}
		
	public Carretera buscarCarreteraArreglo(int laCarretera) {
		return null;
			
	}
		
	public void guardarPartida() {
			
	}
		
	public Carretera nuevaPartida(String pAuto,String pMapa) {
		int numeroCarretera = darNumeroUnicoDeCarretera();
		Carretera nueva = new Carretera(pMapa,numeroCarretera);
		nueva.cambiarAutomovilSeleccionado(pAuto);
		
		return nueva;
		
			
	}
	
	public int darNumeroUnicoDeCarretera() {
		int numero = (int) (Math.random()*(10000-0));;
	
		Carretera carreteraActual=carretera;
		if (carreteraActual==null) {
			
		}else {
			while(carreteraActual!=null) {
				if(carreteraActual.darNumeroCarretera()==numero) {
					carreteraActual=carretera;
					numero=(int) (Math.random()*(10000-0));
				}else {
					carreteraActual.darCarreteraSiguiente();
				}
			}
		}
		
		return numero;
		
		
	}
		
	public String[] darHistorial() {
		return null;
			
	}

	public int darAnchoAutoMovilSeleccionado() {
		// TODO Auto-generated method stub
		return carreteraSeleccionada.darAnchoAutoMovilSeleccionado();
	}

	public int darAlturaAutomovilSeleccionado() {
		// TODO Auto-generated method stub
		return carreteraSeleccionada.darAlturaAutomovilSeleccionado();
	}

	public void avanzar() {
		carreteraSeleccionada.avanzar();
		
	}

	public void detener() {
		carreteraSeleccionada.detener();
		
	}
}
